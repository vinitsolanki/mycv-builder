import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'app-home',
	templateUrl: './home.component.html',
  styleUrls: ['./home.component.sass'],
})
export class HomeComponent {
  active = 'heading';

  tabs = [{
    id: 'heading',
    label: 'HEADING'
  }, {
    id: 'education',
    label: 'EDUCATION'
  }, {
    id: 'workHistory',
    label: 'WORK HISTORY'
  }, {
    id: 'skills',
    label: 'SKILLS'
  }, {
    id: 'summary',
    label: 'SUMMARY'
  }, {
    id: 'finalize',
    label: 'FINALIZE'
  } ];

  form: FormGroup;
  
  constructor(private modalService: NgbModal, private formBuilder: FormBuilder, private route: ActivatedRoute, private router: Router) {

    this.form = this.formBuilder.group({
      'firstName' : ['', [Validators.required, Validators.minLength(2)]],
      'lastName' : ['', [Validators.required, Validators.minLength(2)]],
      'profession' : ['', [Validators.required, Validators.minLength(2)]],
      'city' : ['', [Validators.required, Validators.minLength(2)]],
      'country' : ['', [Validators.required, Validators.minLength(2)]],
      'pinCode' : ['', [Validators.required, Validators.minLength(5)]],
      'phone' : ['', [Validators.required, Validators.maxLength(10), Validators.minLength(10)]],
      'email' : ['', Validators.required]
    });

  }

  submit(value: any) {
  }


}
